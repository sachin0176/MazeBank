package com.jmc.mazebank.views;

public enum AdminMenuOption {

    CREATE_CLIENT,
    CLIENTS,
    DEPOSIT,
    FEEDBACK
}
