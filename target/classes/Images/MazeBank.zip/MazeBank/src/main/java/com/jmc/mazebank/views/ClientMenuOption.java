package com.jmc.mazebank.views;

public enum ClientMenuOption {
    DASHBOARD,
    TRANSACTIONS,
    ACCOUNTS,
    PROFILE


}
