package com.jmc.mazebank.views;

public enum AccountType {

    ADMIN,
    CLIENT
}
