package com.jmc.mazebank.controller;

public class CreateAdminController {
}
